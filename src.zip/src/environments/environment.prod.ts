export const environment = {
  production: true,
  SERVER_URL: 'http://13.233.161.162/api'
};
